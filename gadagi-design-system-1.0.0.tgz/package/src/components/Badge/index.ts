﻿export { Badge } from './Badge';
